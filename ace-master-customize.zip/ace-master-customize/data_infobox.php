<?php


$num_reviews = 11;
$num_comments = 12;
$per_commentreviews = 8;