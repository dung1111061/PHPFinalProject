<?php

include_once "config.php";
include_once "connectDatabase.php";
$sql = "SELECT * FROM product";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $product_id = $row["product_id"];
	$img = $row["image"];
	$price = $row["price"];
	$model = $row["model"];
	$quantity = $row["quantity"];
	$product_name = $row["product_name"];
	$update = $row["update_date"];
?>
<tr>
														<td class="center">
															<label class="pos-rel">
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														
														<td> <?= $product_id ?> </td>
														<td>
															<img src="<?=$img?>" alt="<?=$img?>">
															
																
																	
														</td>
														<td> <?= $product_name ?> </td>
														<td> <?= $price ?> </td>
														<td class="hidden-480"> <?= $model ?> </td>
														<td><?= $update ?></td>

														<td class="hidden-480">
															<span class="label label-sm label-warning"><?= $quantity ?></span>
														</td>

														<td>
															<div class="hidden-sm hidden-xs action-buttons">
																<a class="blue" href="#">
																	<i class="ace-icon fa fa-search-plus bigger-130"></i>
																</a>

																<a class="green" href="#">
																	<i class="ace-icon fa fa-pencil bigger-130"></i>
																</a>

																<a class="red" href="deleteProduct.php?id=<?php echo $product_id ?>">
																	<i class="ace-icon fa fa-trash-o bigger-130"></i>
																</a>
															</div>

															<div class="hidden-md hidden-lg">
																<div class="inline pos-rel">
																	<button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown" data-position="auto">
																		<i class="ace-icon fa fa-caret-down icon-only bigger-120"></i>
																	</button>

																	<ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">
																		<li>
																			<a href="#" class="tooltip-info" data-rel="tooltip" title="View">
																				<span class="blue">
																					<i class="ace-icon fa fa-search-plus bigger-120"></i>
																				</span>
																			</a>
																		</li>

																		<li>
																			<a href="#" class="tooltip-success" data-rel="tooltip" title="Edit">
																				<span class="green">
																					<i class="ace-icon fa fa-pencil-square-o bigger-120"></i>
																				</span>
																			</a>
																		</li>

																		<li>
																			<a href="deleteProduct.php?id= <?php echo $product_id ?>" class="tooltip-error" data-rel="tooltip" title="Delete">
																				<span class="red">
																					<i class="ace-icon fa fa-trash-o bigger-120"></i>
																				</span>
																			</a>
																		</li>
																	</ul>
																</div>
															</div>
														</td>
													</tr>


<?php
    }
} else {
    echo "<script>alert(\"0 result\");</script>";
}

	$conn->close();
?>

<!-- Add evenListener for trash icon to show alert box to confirm delete product -->
<!-- <script>
	var icons = document.getElementById("dynamic-table").getElementsByTagName('i');
	for (var i = icons.length - 1; i >= 0; i--) {
	    if (icons[i].classList.contains("fa-trash-o")) {
	    	icons[i].addEventListener("click", confirmDeleteProduct());	
	    }
	    
	}

	function confirmDeleteProduct() {
  		alert("Are you sure");
	}

</script> -->