					<li class="">
						<a href="dashboard.php">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> Catalog </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="product.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Product List
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="product.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Manufacturers
								</a>

								<b class="arrow"></b>
							</li>	
							<li class="">
								<a href="product.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Reviews
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> Customers </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="product.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Customers
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="product.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Customer Field
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> Sale </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="orders.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Order
								</a>
								<a href="product.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Recurring Orders
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
				