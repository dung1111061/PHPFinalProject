<?php include_once "config.php" ?>

		<ul class="breadcrumb">
			<i class="ace-icon fa fa-home home-icon"></i>
<?php
	$page_path_tree = explode("/",$page_path);
	foreach ($page_path_tree as $node) {
?>
<?php		if ($node === $page_path_tree[count($page_path_tree)-1]) { ?>
				<li class="active"><?= $node ?></li>
<?php		} else { ?>
				<li>
					<a href="<?=page_array[$node]?>"><?= $node ?></a>
				</li>
<?php      } ?>
		<?php
		}
		?>
				
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
