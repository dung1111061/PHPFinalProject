<?php
define(servername, "localhost");
define(username, "root");
define(password, "");
define(dbname, "quanlibanhang");
define(page_array,["Home" => "dashboard.php","Product List" => "product.php"]);