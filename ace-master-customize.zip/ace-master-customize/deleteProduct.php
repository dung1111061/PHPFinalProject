<?php 
include_once "config.php";
include_once "connectDatabase.php";
$id = $_GET["id"];
$sql = "DELETE FROM product WHERE product_id = $id";
$result = $conn->query($sql);
if ($result) echo "delete success";
$conn->close();
header("Location: product.php");