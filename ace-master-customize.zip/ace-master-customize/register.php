<?php
include_once "config.php";
include_once "connectDatabase.php";

$name = $_GET["user"];
$password = $_GET["passwd"];
$email = $_GET["email"];
$sql = "INSERT INTO admin (id, name, password,email) VALUES (1, \"$name\", SHA1(\"$password\"),\"$email\")";
$result = $conn->query($sql);
if(!$result) echo "register failed";

$conn->close();
