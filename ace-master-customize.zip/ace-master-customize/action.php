<?php
include_once "config.php";
include_once "connectDatabase.php";
$sql = "SELECT id, name, password FROM admin";
$result = $conn->query($sql);
        $name= "";
        $password= "";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Name: " . $row["name"]. " " . $row["password"]. "<br>";
        $name= $row["name"];
        $password= $row["password"];
    }
} else {
    echo "0 results";
}
$conn->close();

if(isset($_GET)) {
	$true_verify = ($_GET["user"] === $name && sha1($_GET["passwd"]) === $password) ? true : false;
	if($true_verify){
		header('Location: dashboard.php');
	} else {
		print_r($_GET) ;
        echo sha1($_GET["passwd"]);
	}
}